package Showroom;

public interface SmartCar {
    boolean isSelfDriving();
    boolean isSelfParking();
}
