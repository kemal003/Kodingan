package UAP;

public interface Attack {
    void attack(Avatar target);
}
